fun main(){
    println("good morning. I am your robot Circle")
    val alarm1=Alarm(6,"thursday")
    alarm1.alarm()
    val coffee2=Coffee(2)
    coffee2.coffee()
    coffee2.sugar(2)
    val bath1=Bath(22)
    bath1.bath(22)
    val timetable1=TimeTable("thursday")
    timetable1.timeTable("thursday")
    val cooking2=Cooking()
    cooking2.cooking()
    val clothes1=Clothes("thursday")
    clothes1.clothes("thursday")

}