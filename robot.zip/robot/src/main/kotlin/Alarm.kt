class Alarm(time:Int, day: String):Circle(time, day){
    fun alarm() {

        for (time in 1..12) {
            if (time == 6) {
                println("ring the alarm")
            }
        }
    }

}