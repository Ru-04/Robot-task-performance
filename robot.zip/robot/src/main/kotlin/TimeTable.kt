class TimeTable(day:String) {
    fun timeTable(day: String) {
        val  monday = arrayOf("eng", "hindi")
        val  tuesday = arrayOf("maths", "science")
        val   wednusday = arrayOf("art", "games")
        val  thursday = arrayOf("sst", "hindi")
        val  friday = arrayOf("science", "eng")

        println("arranging timetable of $day")

    }
}