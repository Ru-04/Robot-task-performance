import kotlin.collections.mutableListOf as mutableListOf1

class Cooking {
    fun cooking () {
        val lunch= mutableListOf1("dal","capsicum","rice","cauliflour","curry","roti")
        val breakfast= mutableListOf1("chila","sandwich","paratha","upma","idly","potato")
        val lunch1=lunch.random()
        val breakfast1=breakfast.random()

        println("for breakfast today is $lunch1")
        println("for lunch today is $breakfast1")
    }

}