open class Circle(time:Int, day:String) {
    var time=6
    var day="thursday"
}