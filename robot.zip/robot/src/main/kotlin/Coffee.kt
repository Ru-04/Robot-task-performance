class Coffee( sugar:Int) {
    fun coffee() {

        val coffee1="black"
            if (coffee1 == "black") {
                println("make coffee black")
            } else {
                println("make coffee with milk")
            }






    }
    fun sugar(sugar:Int) {
        println("add $sugar sugar in coffee")
    }
}
