class Bath(temp:Int){
    fun bath(temp: Int){
        println("preparing bath of temp $temp")

    }
}