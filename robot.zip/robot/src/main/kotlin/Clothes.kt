class Clothes(day:String) {
    fun clothes(day: String) {
        val monday = arrayOf("skirt", "top")
        val tuesday = arrayOf("top", "pants")
        val wednusday = arrayOf("top", "jeans")
        val thursday = arrayOf("suit", "pant")
        val friday = arrayOf("top", "jeans")
        println("ironing clothes of day $day")
        }





}